﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ3_Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {   /*
            double number1, number2, result;
            char operation;

            Console.WriteLine("Enter first number");
            number1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter operation type");
            operation = char.Parse(Console.ReadLine());

            Console.WriteLine("Enter second number");
            number2 = double.Parse(Console.ReadLine());

            switch (operation)
            {
                case '+':
                    result = number1 + number2;
                    Console.WriteLine("Result of operation = " + result);
                    break;
                case '-':
                    result = number1 - number2;
                    Console.WriteLine("Result of operation = " + result);
                    break;
                case '*':
                    result = number1 * number2;
                    Console.WriteLine("Result of operation = " + result);
                    break;
                case '/':
                    result = number1 / number2;
                    Console.WriteLine("Result of operation = " + result);
                    break;
                case ':':
                    result = number1 / number2;
                    Console.WriteLine("Result of operation = " + result);
                    break;
                default:
                    break;
            */




            /*

            double number1, number2, result;
            char operation;

            number1 = double.Parse(Console.ReadLine());

            operation = char.Parse(Console.ReadLine());

            number2 = double.Parse(Console.ReadLine());

            switch (operation)
            {
                case '+':
                    result = number1 + number2;
                    Console.WriteLine("=");
                    Console.WriteLine(result);
                    break;
                case '-':
                    result = number1 - number2;
                    Console.WriteLine("=");
                    Console.WriteLine(result);
                    break;
                case '*':
                    result = number1 * number2;
                    Console.WriteLine("=");
                    Console.WriteLine(result);
                    break;
                case '/':
                    result = number1 / number2;
                    Console.WriteLine("=");
                    Console.WriteLine(result);
                    break;
                case ':':
                    result = number1 / number2;
                    Console.WriteLine("=");
                    Console.WriteLine(result);
                    break;
                default:
                    break;

            */


            double number1, number2, result;
            char operation;

            number1 = double.Parse(Console.ReadLine());

            operation = char.Parse(Console.ReadLine());

            number2 = double.Parse(Console.ReadLine());


            if (operation == '+')
            {
                result = number1 + number2;
                Console.WriteLine("=");
                Console.WriteLine(result);
            }
            else if (operation == '-')
            {
                result = number1 - number2;
                Console.WriteLine("=");
                Console.WriteLine(result);
            }
            else if (operation == '*')
            {
                result = number1 * number2;
                Console.WriteLine("=");
                Console.WriteLine(result);
            }
            else if (operation == '/')
            {
                result = number1 / number2;
                Console.WriteLine("=");
                Console.WriteLine(result);
            }
            else if (operation == ':')
            {
                result = number1 / number2;
                Console.WriteLine("=");
                Console.WriteLine(result);
            }
            else
            {
                Console.WriteLine("Неверные символы!");
            }


        }

    }
}

